import openai
import feedparser
import requests
from requests.auth import HTTPBasicAuth
import os

# Конфигурација од Railway Variables
OPENAI_API_KEY = os.environ['OPENAI_API_KEY']
WP_URL = os.environ['WP_URL']
WP_USER = os.environ['WP_USER']
WP_PASS = os.environ['WP_PASS']

openai.api_key = OPENAI_API_KEY

# RSS извори
RSS_FEEDS = [
    "https://www.slobodenpecat.mk/feed/",
    "https://faktor.mk/rss.xml",
    "https://a1on.mk/feed/",
    "https://24info.mk/feed/"
]

# Читање статии
def collect_articles():
    articles = []
    for feed_url in RSS_FEEDS:
        feed = feedparser.parse(feed_url)
        for entry in feed.entries[:2]:  # земи 2 најнови
            articles.append({
                "title": entry.title,
                "summary": entry.summary,
                "link": entry.link
            })
    return articles

# Генерирање со GPT-4
def generate_article_from_multiple(articles):
    prompt = "Прочитај ги следниве вести и состави нова оригинална статија на македонски јазик со нов наслов."
    for i, art in enumerate(articles):
        prompt += f"\n\n{i+1}. {art['title']} - {art['summary']}"

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "Ти си искусен новинар кој пишува јасни, концизни и оригинални вести на македонски јазик."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.7,
        max_tokens=1000
    )
    return response.choices[0].message.content.strip()

# Објави на WordPress
def publish_to_wordpress(title, content):
    post = {
        "title": title,
        "content": content,
        "status": "publish"
    }
    response = requests.post(f"{WP_URL}/wp-json/wp/v2/posts",
                             auth=HTTPBasicAuth(WP_USER, WP_PASS),
                             json=post)
    return response.json()

# MAIN FLOW
if __name__ == "__main__":
    all_articles = collect_articles()
    generated_article = generate_article_from_multiple(all_articles[:3])

    if "\n" in generated_article:
        lines = generated_article.split("\n", 1)
        title = lines[0].strip("#:- ")
        body = lines[1].strip()
    else:
        title = "AI Генерирана Вест"
        body = generated_article

    publish_to_wordpress(title, body)
    print("✔ Објавена нова AI вест на WordPress!")
git remote add origin https://github.com/streamer-mk/rss-to-wordpress.git
git branch -M main
git push -u origin main