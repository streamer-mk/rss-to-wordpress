import feedparser
import requests
from requests.auth import HTTPBasicAuth

# Конфигурација за твојот WordPress
WP_URL = 'https://example.com/wp-json/wp/v2/posts'
WP_USER = 'your_username'
WP_APP_PASSWORD = 'your_application_password'
RSS_FEED_PATH = 'generated_rss/makedonija.xml'

def publish_to_wordpress():
    feed = feedparser.parse(RSS_FEED_PATH)

    for entry in feed.entries:
        title = entry.title
        content = entry.description
        link = entry.link

        post = {
            'title': title,
            'content': f'{content}<br><br>Извор: <a href="{link}">{link}</a>',
            'status': 'publish'
        }

        response = requests.post(
            WP_URL,
            auth=HTTPBasicAuth(WP_USER, WP_APP_PASSWORD),
            json=post
        )

        if response.status_code == 201:
            print(f"✅ Објавено: {title}")
        else:
            print(f"❌ Неуспех за {title} | Status: {response.status_code} | Response: {response.text}")

if __name__ == '__main__':
    publish_to_wordpress()
