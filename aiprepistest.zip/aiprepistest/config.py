# Подеси ги овие вредности со твоите
WORDPRESS_URL = "https://tvoj-sajt.mk"
WORDPRESS_USERNAME = "korisnik"
WORDPRESS_PASSWORD = "lozinka"
CATEGORY = "Македонија"
