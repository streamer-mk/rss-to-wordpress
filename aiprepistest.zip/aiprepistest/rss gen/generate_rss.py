import os
import requests
from bs4 import BeautifulSoup
from datetime import datetime
from feedgen.feed import FeedGenerator

# Конфигурација
BASE_URL = "https://www.vesti.mk/category/makedonija"
OUTPUT_DIR = "generated_rss"
RSS_FILENAME = "makedonija.xml"

# Креирај фолдер ако не постои
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Земи ја HTML содржината
response = requests.get(BASE_URL)
soup = BeautifulSoup(response.content, 'html.parser')

# Генерирај RSS
fg = FeedGenerator()
fg.title("Македонија Вести - vesti.mk")
fg.link(href=BASE_URL, rel='alternate')
fg.description("Автоматски генериран RSS feed од vesti.mk категорија Македонија")
fg.language('mk')

# Извлечи линкови до статии
articles = soup.select('div.media-body a')[:10]

for a in articles:
    title = a.get_text(strip=True)
    link = a['href']
    if not link.startswith("http"):
        link = "https://vesti.mk" + link
    entry = fg.add_entry()
    entry.title(title)
    entry.link(href=link)
    entry.guid(link)
    entry.pubDate(datetime.now())

# Запиши XML фајл
rss_path = os.path.join(OUTPUT_DIR, RSS_FILENAME)
fg.rss_file(rss_path)

print(f"RSS feed saved to {rss_path}")
